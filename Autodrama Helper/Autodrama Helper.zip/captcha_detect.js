if (window.location.pathname.match(/Special/))
{
    SaveToDisk("eFeNotAvail", "err.autodramatext", 1)
}